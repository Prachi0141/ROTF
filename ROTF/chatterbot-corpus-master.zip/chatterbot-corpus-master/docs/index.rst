.. chatterbot-corpus documentation master file, created by
   sphinx-quickstart on Wed Aug 16 23:03:03 2017.

ChatterBot Corpus Documentation
===============================

The ChatterBot Corpus is a project containing user-contributed
dialog data that can be used to train chat bots to communicate.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   corpus
   data

Using the ChatterBot Corpus with ChatterBot
+++++++++++++++++++++++++++++++++++++++++++

If you are looking for information on how to
use the ``chatterbot-corpus`` module with your
chat bot build with ChatterBot, then you will
want to take a look at the `ChatterBot Documentation`_

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

.. _ChatterBot Documentation: http://chatterbot.readthedocs.io/en/latest/corpus.html
